using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Namespace;
public class UIAngle : MonoBehaviour
{
    public static UIAngle InstanceAngle;
    private string input;
    private behaviourScript behaviourScriptInstance;

    private void Awake()
    {
        InstanceAngle = this;
        behaviourScriptInstance = FindObjectOfType<behaviourScript>();

    }

    public void readStringInputAngle(string s)
    {
        input = s;
        Debug.Log(input);
        double result = 0;
        if (double.TryParse(input, out result))
        {
            behaviourScriptInstance.Raw_axis_angle[0] = result/(1.0f / Time.deltaTime);
        }
        else
        {
            Debug.LogError("Input is not a valid double: " + input);
        } 
    }
}
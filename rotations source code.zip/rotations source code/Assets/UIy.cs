using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Namespace;
public class UIy : MonoBehaviour
{
    public static UIy Instancey;
    private string input;
    private behaviourScript behaviourScriptInstance;

    private void Awake()
    {
        Instancey = this;
        behaviourScriptInstance = FindObjectOfType<behaviourScript>();

    }

    public void readStringInputy(string s)
    {
        input = s;
        Debug.Log(input);
        double result = 0;
        if (double.TryParse(input, out result))
        {
            behaviourScriptInstance.Raw_axis_angle[2] = result;
        }
        else
        {
            Debug.LogError("Input is not a valid double: " + input);
        } 
    }
}

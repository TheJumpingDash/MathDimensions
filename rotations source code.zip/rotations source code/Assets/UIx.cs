using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Namespace;
public class UIx : MonoBehaviour
{
    public static UIx Instancex;
    private string input;
    private behaviourScript behaviourScriptInstance;

    private void Awake()
    {
        Instancex = this;
        behaviourScriptInstance = FindObjectOfType<behaviourScript>();

    }

    public void readStringInputx(string s)
    {
        input = s;
        Debug.Log(input);
        double result = 0;
        if (double.TryParse(input, out result))
        {
            behaviourScriptInstance.Raw_axis_angle[1] = result;
        }
        else
        {
            Debug.LogError("Input is not a valid double: " + input);
        } 
    }
}
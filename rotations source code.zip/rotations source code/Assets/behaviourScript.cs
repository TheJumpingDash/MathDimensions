using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;


namespace Namespace
{
    public class behaviourScript : MonoBehaviour
    {   //declarant totes les variables
        public double[] Raw_axis_angle= { 0.0005, 0, 0, 1}; //representació axis-angle no unitària
        private double[] Unit_axis_angle;
        private double[] rotationQuaternion= {0, 0, 0, 0};
        private double[] pointQuaternion= {0, 0, 0, 0};
        private double[] newPoint= {0, 0, 0, 0};

        void Start()
        {
            QualitySettings.vSyncCount = 0; //força els frames per segon a seixanta, per evitar moviment inconsistent del cub. (com és un programa molt senzill, els fps no haurien de baixar de 60)
            Application.targetFrameRate = 60;
        }
        void MoveVertices() //com diu el seu nom, funció que mou els vèrtex
        {
            Mesh mesh = GetComponent<MeshFilter>().mesh;
            Vector3[] vertices = mesh.vertices; //genera una llista amb tots els punts del cub


            for (int i = 0; i < vertices.Length; i++) //loop per cada punt del cub
            {
                for (int o = 1; o < 4; o++)
                {
                pointQuaternion[o] = vertices[i][(o-1)]; //pointQuaternion és el array que emmagatzema la posició de cada punt, en coordenades xyz
                }
                newPoint = Multiplication(Multiplication(Inversion(rotationQuaternion), pointQuaternion), rotationQuaternion);
                vertices[i] = new Vector3((float)newPoint[1], (float)newPoint[2], (float)newPoint[3]);  //aquesta és la part que usa les funcions "inversió" i "multiplicació" com a l'explicació  
               
            }


            mesh.vertices = vertices;
            mesh.RecalculateBounds();//actualitza el cub
        }


        static double[] UnitVector(double[] a)  //transforma a vector unitari
        {
            double magnitude = System.Math.Sqrt(a[1]*a[1] + a[2]*a[2] + a[3]*a[3]);
            double[] UnitVector = new double[] {a[0], a[1]/magnitude, a[2]/magnitude, a[3]/magnitude};
            return UnitVector;
        }


        static double[] Multiplication(double[] a, double[] b) //executa la multiplicació de quaternions
        {
            double[] c = new double[] {0, 0, 0, 0};
            c[0] = a[0]*b[0] - a[1]*b[1] - a[2]*b[2] - a[3]*b[3];
            c[1] = a[0]*b[1] + a[1]*b[0] - a[2]*b[3] + a[3]*b[2];
            c[2] = a[0]*b[2] + a[1]*b[3] + a[2]*b[0] - a[3]*b[1];
            c[3] = a[0]*b[3] - a[1]*b[2] + a[2]*b[1] + a[3]*b[0];
            return c;
        }
        static double[] Inversion(double[] a) //executa la inversió de quaternions
        {
            double[] b = new double[] {0, 0, 0, 0};
            b[0] = a[0]; b[1] = -a[1]; b[2] = -a[2]; b[3] = -a[3];
            return b;
        }


        void Update()
        {  
            if ((Raw_axis_angle[1]!=0) || (Raw_axis_angle[2]!=0) || (Raw_axis_angle[3]!=0)) //necessari per a evitar el cas que tots els valors al quaternió valen 0
            {
               
                Unit_axis_angle= UnitVector(Raw_axis_angle); //aplica la funció que converteix el vector en unitari
                rotationQuaternion[0] = Math.Cos(Unit_axis_angle[0]/2); //passa de axis-angle a quaternió
                for (int i = 1; i < 4; i++)
                {
                    rotationQuaternion[i] = Unit_axis_angle[i] * System.Math.Sin(Unit_axis_angle[0]/2);
                }
                MoveVertices();
            }
        }  
    }
}
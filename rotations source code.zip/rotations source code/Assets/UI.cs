using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Namespace;
public class UI : MonoBehaviour
{
    public static UI Instance;
    private string input;
    private behaviourScript behaviourScriptInstance;

    private void Awake()
    {
        Instance = this;
        behaviourScriptInstance = FindObjectOfType<behaviourScript>();

    }

    public void readStringInputz(string s)
    {
        input = s;
        Debug.Log(input);
        double result = 0;
        if (double.TryParse(input, out result))
        {
            behaviourScriptInstance.Raw_axis_angle[3] = result;
        }
        else
        {
            Debug.LogError("Input is not a valid double: " + input);
        } 
    }
}